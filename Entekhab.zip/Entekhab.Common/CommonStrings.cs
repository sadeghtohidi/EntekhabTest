﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rasad.Common
{
    public static class CommonStrings
    {
        public static string CommonUrl { get { return @"https://10.100.10.57/api/"; } }
    }
}
