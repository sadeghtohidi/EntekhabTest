﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entekhab.Services.Common.AutoFac
{
    //just to mark
    public interface IScopedDependency
    {
    }

    public interface ITransientDependency
    {
    }

    public interface ISingletonDependency
    {
    }
}
