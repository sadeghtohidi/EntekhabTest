﻿using Microsoft.AspNetCore.Http;
using Entekhab.Common.DataAnnotation;
using Entekhab.Services.Dto.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entekhab.Services.Dto.GetFile
{
    public class GetXmlRequestDto : GetFileRequestDto
    {
        
    }
}
