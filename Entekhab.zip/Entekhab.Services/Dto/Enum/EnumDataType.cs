﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entekhab.Services.Dto.Enum
{
    public enum EnumDataType
    {
        Json,
        Xml,
        Csv,
        Custom
    }
}
