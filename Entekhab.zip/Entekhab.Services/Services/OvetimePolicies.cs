﻿using Entekhab.Services.Contract;
using Entekhab.Services.Dto.GetFile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entekhab.Services.Services
{
    public class OvetimePolicies : IOvetimePolicies
    {
        public void CalcurlatorA(List<SalaryGetModel> request)
        {
            
        }

        public void CalcurlatorB(List<SalaryGetModel> request)
        {
            
        }

        public void CalcurlatorC(List<SalaryGetModel> request)
        {
            
        }
    }
}
