﻿using Data.Repositories;
using Entekhab.Services.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entekhab.Services.Services
{
    public class TestService : ITestService
    {

        public TestService()
        {
           
        }
        public void TestMethod()
        {
            //var tt = _product.Table.ToList();
        }
    }
}
